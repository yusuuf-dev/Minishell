#include "minishell.h"

int main(int ac, char **av)
{
    char *p;

    (void)av;
    (void)ac;

    while (1)
    {
        p = readline("minishell : ");
        parsing(p);
        add_history(p);
        free(p);
    }
    
}