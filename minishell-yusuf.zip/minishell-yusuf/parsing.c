#include "minishell.h"

// char *built_cmd(char *cmd)
// {
//     return(NULL);
//     return ("echo");
// }

void    parsing(char *p)
{
    char    *env;
    char    **env_paths;
    char    **rdl_args;

    env = getenv("PATH");
    if (!env)
    {
        printf("home PATH not foound\n");
        return;
    }
    env_paths = ft_split(env,':');
    rdl_args = ft_split(p,' ');

    int i = 0;
    char   *path;
    char    *temp;
    while (env_paths[i])
    {
        temp = ft_strjoin(env_paths[i], "/");
        path = ft_strjoin(temp,rdl_args[0]);
        free(temp);
        if(execve(path,rdl_args,NULL) !=  -1)
            break;
        free(path);
        i++;
    }

}
