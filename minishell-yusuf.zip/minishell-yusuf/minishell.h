#ifndef MINISHELL_H
#define MINISHELL_H

#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int     minishell(int ac, char **av);
void    parsing(char *p);
char	*ft_remove_isspace(char *s);
char	**ft_split(char *str, char c);
char	*ft_strjoin(char *s1, char *s2);

#endif